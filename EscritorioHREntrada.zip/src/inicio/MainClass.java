package inicio;

import vistas.MainForm;

/**
 *
 * @author Antonio Company Rodriguez
 */
public class MainClass {
    public static void main(String[] args) {
        MainForm ventana = new MainForm();
        ventana.setVisible(true);
    }
}
