Proyecto final de CFGS DAM

[Enlace al servidor del proyecto](https://github.com/Trope16121980/ServerHREntrada)

[Enlace a la parte mobil del proyecto]( https://github.com/davidval2022/HREntradaClienteApp-)
